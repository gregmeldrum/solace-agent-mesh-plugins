# ObjectDetection SAM Plugin

Object detection from image

This is a plugin for Solace Agent Mesh (SAM).

## Installation

Once the plugin is installed (e.g., from PyPI or a local wheel file):
```bash
sam plugin add <your-new-component-name> --plugin object-detection
```