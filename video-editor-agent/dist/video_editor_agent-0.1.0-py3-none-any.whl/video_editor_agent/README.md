# VideoEditorAgent SAM Plugin

A SAM plugin: video editor agent

This is a plugin for Solace Agent Mesh (SAM).

## Installation

Once the plugin is installed (e.g., from PyPI or a local wheel file):
```bash
sam plugin add <your-new-component-name> --plugin video-editor-agent
```