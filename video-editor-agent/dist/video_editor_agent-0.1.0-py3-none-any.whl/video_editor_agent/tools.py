import logging
import os
import tempfile
import subprocess
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from google.adk.tools import ToolContext
from solace_agent_mesh.agent.utils.artifact_helpers import (
    save_artifact_with_metadata,
    DEFAULT_SCHEMA_MAX_KEYS,
)
from solace_agent_mesh.agent.utils.context_helpers import get_original_session_id

log = logging.getLogger(__name__)

# Supported formats
VIDEO_FORMATS = ["mp4", "mkv", "avi", "webm", "mov", "flv"]
AUDIO_FORMATS = ["mp3", "wav", "aac", "flac", "ogg", "m4a"]

# Quality presets for encoding
VIDEO_QUALITY_PRESETS = {
    "high": {"crf": "18", "preset": "slow"},
    "medium": {"crf": "23", "preset": "medium"},
    "low": {"crf": "28", "preset": "fast"}
}


async def _load_artifact_as_temp_file(
    artifact_service,
    app_name: str,
    user_id: str,
    session_id: str,
    artifact_filename: str,
    temp_dir: str
) -> str:
    """
    Load an artifact from the artifact service and save it as a temporary file.

    Returns:
        Path to the temporary file
    """
    log_id = "[VideoEditorTools:_load_artifact]"

    try:
        # Load the artifact using the correct API
        artifact = await artifact_service.load_artifact(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=artifact_filename
        )

        # Extract the bytes content from the artifact
        # The artifact object has inline_data.data containing the bytes
        if hasattr(artifact, 'inline_data') and hasattr(artifact.inline_data, 'data'):
            content = artifact.inline_data.data
        else:
            raise ValueError(f"Artifact does not have expected inline_data.data structure")

        # Determine file extension from original filename
        _, ext = os.path.splitext(artifact_filename)

        # Save to temporary file
        temp_file_path = os.path.join(temp_dir, f"input{ext}")

        with open(temp_file_path, 'wb') as f:
            f.write(content)

        log.info(f"{log_id} Loaded artifact '{artifact_filename}' to {temp_file_path}")
        return temp_file_path

    except Exception as e:
        log.error(f"{log_id} Failed to load artifact: {e}")
        raise


async def convert_video_format(
    input_artifact: str,
    output_format: str,
    quality: str = "medium",
    tool_context: Optional[ToolContext] = None,
    tool_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Convert a video file to a different format.

    Args:
        input_artifact: Name of the input video artifact
        output_format: Target format (mp4, mkv, avi, webm, mov, flv)
        quality: Encoding quality preset (high, medium, low). Default: medium

    Returns:
        A dictionary with status, message, and output artifact information
    """
    plugin_name = "video-editor-tools"
    log_identifier = f"[{plugin_name}:convert_video_format]"
    log.info(f"{log_identifier} Converting '{input_artifact}' to {output_format}")

    # Validate format
    if output_format.lower() not in VIDEO_FORMATS:
        return {
            "status": "error",
            "message": f"Invalid format '{output_format}'. Supported: {', '.join(VIDEO_FORMATS)}"
        }

    # Validate quality
    if quality not in VIDEO_QUALITY_PRESETS:
        log.warning(f"{log_identifier} Invalid quality '{quality}', using 'medium'")
        quality = "medium"

    # Validate tool context
    if not tool_context or not tool_context._invocation_context:
        log.error(f"{log_identifier} ToolContext or InvocationContext is missing.")
        return {
            "status": "error",
            "message": "ToolContext or InvocationContext is missing.",
        }

    inv_context = tool_context._invocation_context
    app_name = getattr(inv_context, "app_name", None)
    user_id = getattr(inv_context, "user_id", None)
    session_id = get_original_session_id(inv_context)
    artifact_service = getattr(inv_context, "artifact_service", None)

    if not all([app_name, user_id, session_id, artifact_service]):
        return {
            "status": "error",
            "message": "Missing required context parts for artifact operations",
        }

    # Create temporary directory
    temp_dir = tempfile.mkdtemp(prefix="video_convert_")
    temp_input = None
    temp_output = None

    try:
        # Load input video from artifact
        temp_input = await _load_artifact_as_temp_file(
            artifact_service, app_name, user_id, session_id,
            input_artifact, temp_dir
        )

        # Prepare output path
        temp_output = os.path.join(temp_dir, f"output.{output_format}")

        # Get quality settings
        settings = VIDEO_QUALITY_PRESETS[quality]

        # Build ffmpeg command
        cmd = [
            "ffmpeg",
            "-i", temp_input,
            "-c:v", "libx264",
            "-crf", settings["crf"],
            "-preset", settings["preset"],
            "-c:a", "aac",
            "-b:a", "192k",
            "-y",  # Overwrite output file
            temp_output
        ]

        log.info(f"{log_identifier} Running ffmpeg conversion")

        # Run ffmpeg
        timeout = tool_config.get("timeout_seconds", 600) if tool_config else 600
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if result.returncode != 0:
            log.error(f"{log_identifier} FFmpeg failed: {result.stderr}")
            return {
                "status": "error",
                "message": f"Video conversion failed: {result.stderr[:300]}"
            }

        log.info(f"{log_identifier} Conversion completed successfully")

        # Read output file
        with open(temp_output, 'rb') as f:
            output_content = f.read()

        # Generate output filename
        timestamp = datetime.now(timezone.utc)
        input_base = os.path.splitext(input_artifact)[0]
        output_filename = f"{input_base}_converted.{output_format}"

        # Save as artifact
        metadata_dict = {
            "description": f"Video converted from {input_artifact} to {output_format}",
            "source_tool": "convert_video_format",
            "input_artifact": input_artifact,
            "output_format": output_format,
            "quality": quality,
            "creation_timestamp_iso": timestamp.isoformat(),
        }

        log.info(f"{log_identifier} Saving output artifact: {output_filename}")

        save_result = await save_artifact_with_metadata(
            artifact_service=artifact_service,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=output_filename,
            content_bytes=output_content,
            mime_type=f"video/{output_format}",
            metadata_dict=metadata_dict,
            timestamp=timestamp,
            schema_max_keys=DEFAULT_SCHEMA_MAX_KEYS,
            tool_context=tool_context,
        )

        if save_result.get("status") == "error":
            log.error(f"{log_identifier} Failed to save artifact: {save_result.get('message')}")
            return {
                "status": "error",
                "message": f"Failed to save artifact: {save_result.get('message')}",
            }

        log.info(f"{log_identifier} Artifact saved successfully")

        return {
            "status": "success",
            "message": f"Successfully converted video to {output_format}",
            "output_artifact": output_filename,
            "output_version": save_result["data_version"],
            "file_size_bytes": len(output_content),
            "quality": quality,
        }

    except subprocess.TimeoutExpired:
        log.error(f"{log_identifier} Conversion timed out")
        return {
            "status": "error",
            "message": f"Video conversion timed out after {timeout} seconds"
        }
    except FileNotFoundError as e:
        log.error(f"{log_identifier} Artifact not found: {e}")
        return {
            "status": "error",
            "message": str(e)
        }
    except Exception as e:
        log.exception(f"{log_identifier} Unexpected error: {e}")
        return {
            "status": "error",
            "message": f"Unexpected error during conversion: {str(e)}"
        }
    finally:
        # Cleanup temporary files
        try:
            if temp_input and os.path.exists(temp_input):
                os.remove(temp_input)
            if temp_output and os.path.exists(temp_output):
                os.remove(temp_output)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
            log.info(f"{log_identifier} Cleaned up temporary files")
        except Exception as e:
            log.warning(f"{log_identifier} Error cleaning up: {e}")


async def trim_video(
    input_artifact: str,
    start_time: float,
    end_time: float,
    tool_context: Optional[ToolContext] = None,
    tool_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Trim a video to a specific time range.

    Args:
        input_artifact: Name of the input video artifact
        start_time: Start time in seconds (e.g., 10.5 for 10.5 seconds)
        end_time: End time in seconds (e.g., 60.0 for 1 minute)

    Returns:
        A dictionary with status, message, and output artifact information
    """
    plugin_name = "video-editor-tools"
    log_identifier = f"[{plugin_name}:trim_video]"
    log.info(f"{log_identifier} Trimming '{input_artifact}' from {start_time}s to {end_time}s")

    # Validate times
    if start_time < 0 or end_time <= start_time:
        return {
            "status": "error",
            "message": "Invalid time range. end_time must be greater than start_time, and both must be positive."
        }

    # Validate tool context
    if not tool_context or not tool_context._invocation_context:
        return {
            "status": "error",
            "message": "ToolContext or InvocationContext is missing.",
        }

    inv_context = tool_context._invocation_context
    app_name = getattr(inv_context, "app_name", None)
    user_id = getattr(inv_context, "user_id", None)
    session_id = get_original_session_id(inv_context)
    artifact_service = getattr(inv_context, "artifact_service", None)

    if not all([app_name, user_id, session_id, artifact_service]):
        return {
            "status": "error",
            "message": "Missing required context parts for artifact operations",
        }

    temp_dir = tempfile.mkdtemp(prefix="video_trim_")
    temp_input = None
    temp_output = None

    try:
        # Load input video
        temp_input = await _load_artifact_as_temp_file(
            artifact_service, app_name, user_id, session_id,
            input_artifact, temp_dir
        )

        # Prepare output path
        input_ext = os.path.splitext(input_artifact)[1]
        temp_output = os.path.join(temp_dir, f"output{input_ext}")

        # Calculate duration
        duration = end_time - start_time

        # Build ffmpeg command
        cmd = [
            "ffmpeg",
            "-i", temp_input,
            "-ss", str(start_time),
            "-t", str(duration),
            "-c", "copy",  # Copy codec without re-encoding for speed
            "-y",
            temp_output
        ]

        log.info(f"{log_identifier} Running ffmpeg trim")

        # Run ffmpeg
        timeout = tool_config.get("timeout_seconds", 600) if tool_config else 600
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if result.returncode != 0:
            log.error(f"{log_identifier} FFmpeg failed: {result.stderr}")
            return {
                "status": "error",
                "message": f"Video trim failed: {result.stderr[:300]}"
            }

        log.info(f"{log_identifier} Trim completed successfully")

        # Read output file
        with open(temp_output, 'rb') as f:
            output_content = f.read()

        # Generate output filename
        timestamp = datetime.now(timezone.utc)
        input_base = os.path.splitext(input_artifact)[0]
        output_filename = f"{input_base}_trimmed_{int(start_time)}-{int(end_time)}s{input_ext}"

        # Save as artifact
        metadata_dict = {
            "description": f"Video trimmed from {start_time}s to {end_time}s",
            "source_tool": "trim_video",
            "input_artifact": input_artifact,
            "start_time": start_time,
            "end_time": end_time,
            "duration": duration,
            "creation_timestamp_iso": timestamp.isoformat(),
        }

        save_result = await save_artifact_with_metadata(
            artifact_service=artifact_service,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=output_filename,
            content_bytes=output_content,
            mime_type=f"video/{input_ext.lstrip('.')}",
            metadata_dict=metadata_dict,
            timestamp=timestamp,
            schema_max_keys=DEFAULT_SCHEMA_MAX_KEYS,
            tool_context=tool_context,
        )

        if save_result.get("status") == "error":
            return {
                "status": "error",
                "message": f"Failed to save artifact: {save_result.get('message')}",
            }

        return {
            "status": "success",
            "message": f"Successfully trimmed video from {start_time}s to {end_time}s",
            "output_artifact": output_filename,
            "output_version": save_result["data_version"],
            "file_size_bytes": len(output_content),
            "duration_seconds": duration,
        }

    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "message": f"Video trim timed out after {timeout} seconds"
        }
    except FileNotFoundError as e:
        return {
            "status": "error",
            "message": str(e)
        }
    except Exception as e:
        log.exception(f"{log_identifier} Unexpected error: {e}")
        return {
            "status": "error",
            "message": f"Unexpected error during trim: {str(e)}"
        }
    finally:
        try:
            if temp_input and os.path.exists(temp_input):
                os.remove(temp_input)
            if temp_output and os.path.exists(temp_output):
                os.remove(temp_output)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception as e:
            log.warning(f"{log_identifier} Error cleaning up: {e}")


async def extract_audio(
    input_artifact: str,
    output_format: str = "mp3",
    tool_context: Optional[ToolContext] = None,
    tool_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Extract audio from a video file.

    Args:
        input_artifact: Name of the input video artifact
        output_format: Audio format (mp3, wav, aac, flac, ogg, m4a). Default: mp3

    Returns:
        A dictionary with status, message, and output artifact information
    """
    plugin_name = "video-editor-tools"
    log_identifier = f"[{plugin_name}:extract_audio]"
    log.info(f"{log_identifier} Extracting audio from '{input_artifact}' as {output_format}")

    # Validate format
    if output_format.lower() not in AUDIO_FORMATS:
        return {
            "status": "error",
            "message": f"Invalid format '{output_format}'. Supported: {', '.join(AUDIO_FORMATS)}"
        }

    # Validate tool context
    if not tool_context or not tool_context._invocation_context:
        return {
            "status": "error",
            "message": "ToolContext or InvocationContext is missing.",
        }

    inv_context = tool_context._invocation_context
    app_name = getattr(inv_context, "app_name", None)
    user_id = getattr(inv_context, "user_id", None)
    session_id = get_original_session_id(inv_context)
    artifact_service = getattr(inv_context, "artifact_service", None)

    if not all([app_name, user_id, session_id, artifact_service]):
        return {
            "status": "error",
            "message": "Missing required context parts for artifact operations",
        }

    temp_dir = tempfile.mkdtemp(prefix="audio_extract_")
    temp_input = None
    temp_output = None

    try:
        # Load input video
        temp_input = await _load_artifact_as_temp_file(
            artifact_service, app_name, user_id, session_id,
            input_artifact, temp_dir
        )

        # Prepare output path
        temp_output = os.path.join(temp_dir, f"output.{output_format}")

        # Build ffmpeg command
        cmd = [
            "ffmpeg",
            "-i", temp_input,
            "-vn",  # No video
            "-acodec", "libmp3lame" if output_format == "mp3" else "copy",
            "-q:a", "2",  # Good quality
            "-y",
            temp_output
        ]

        log.info(f"{log_identifier} Running ffmpeg audio extraction")

        # Run ffmpeg
        timeout = tool_config.get("timeout_seconds", 300) if tool_config else 300
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if result.returncode != 0:
            log.error(f"{log_identifier} FFmpeg failed: {result.stderr}")
            return {
                "status": "error",
                "message": f"Audio extraction failed: {result.stderr[:300]}"
            }

        log.info(f"{log_identifier} Audio extraction completed successfully")

        # Read output file
        with open(temp_output, 'rb') as f:
            output_content = f.read()

        # Generate output filename
        timestamp = datetime.now(timezone.utc)
        input_base = os.path.splitext(input_artifact)[0]
        output_filename = f"{input_base}_audio.{output_format}"

        # Save as artifact
        metadata_dict = {
            "description": f"Audio extracted from {input_artifact}",
            "source_tool": "extract_audio",
            "input_artifact": input_artifact,
            "output_format": output_format,
            "creation_timestamp_iso": timestamp.isoformat(),
        }

        save_result = await save_artifact_with_metadata(
            artifact_service=artifact_service,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=output_filename,
            content_bytes=output_content,
            mime_type=f"audio/{output_format}",
            metadata_dict=metadata_dict,
            timestamp=timestamp,
            schema_max_keys=DEFAULT_SCHEMA_MAX_KEYS,
            tool_context=tool_context,
        )

        if save_result.get("status") == "error":
            return {
                "status": "error",
                "message": f"Failed to save artifact: {save_result.get('message')}",
            }

        return {
            "status": "success",
            "message": f"Successfully extracted audio as {output_format}",
            "output_artifact": output_filename,
            "output_version": save_result["data_version"],
            "file_size_bytes": len(output_content),
        }

    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "message": f"Audio extraction timed out after {timeout} seconds"
        }
    except FileNotFoundError as e:
        return {
            "status": "error",
            "message": str(e)
        }
    except Exception as e:
        log.exception(f"{log_identifier} Unexpected error: {e}")
        return {
            "status": "error",
            "message": f"Unexpected error during audio extraction: {str(e)}"
        }
    finally:
        try:
            if temp_input and os.path.exists(temp_input):
                os.remove(temp_input)
            if temp_output and os.path.exists(temp_output):
                os.remove(temp_output)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception as e:
            log.warning(f"{log_identifier} Error cleaning up: {e}")


async def compress_video(
    input_artifact: str,
    target_size_mb: Optional[float] = None,
    quality: Optional[str] = None,
    tool_context: Optional[ToolContext] = None,
    tool_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Compress a video file by target size or quality preset.

    Args:
        input_artifact: Name of the input video artifact
        target_size_mb: Target file size in megabytes (optional)
        quality: Quality preset (high, medium, low) - used if target_size_mb not specified

    Returns:
        A dictionary with status, message, and output artifact information
    """
    plugin_name = "video-editor-tools"
    log_identifier = f"[{plugin_name}:compress_video]"
    log.info(f"{log_identifier} Compressing '{input_artifact}'")

    # Validate parameters
    if target_size_mb is None and quality is None:
        quality = "medium"  # Default

    if quality and quality not in VIDEO_QUALITY_PRESETS:
        return {
            "status": "error",
            "message": f"Invalid quality '{quality}'. Supported: {', '.join(VIDEO_QUALITY_PRESETS.keys())}"
        }

    # Validate tool context
    if not tool_context or not tool_context._invocation_context:
        return {
            "status": "error",
            "message": "ToolContext or InvocationContext is missing.",
        }

    inv_context = tool_context._invocation_context
    app_name = getattr(inv_context, "app_name", None)
    user_id = getattr(inv_context, "user_id", None)
    session_id = get_original_session_id(inv_context)
    artifact_service = getattr(inv_context, "artifact_service", None)

    if not all([app_name, user_id, session_id, artifact_service]):
        return {
            "status": "error",
            "message": "Missing required context parts for artifact operations",
        }

    temp_dir = tempfile.mkdtemp(prefix="video_compress_")
    temp_input = None
    temp_output = None

    try:
        # Load input video
        temp_input = await _load_artifact_as_temp_file(
            artifact_service, app_name, user_id, session_id,
            input_artifact, temp_dir
        )

        # Prepare output path
        input_ext = os.path.splitext(input_artifact)[1]
        temp_output = os.path.join(temp_dir, f"output{input_ext}")

        # Build compression command
        if target_size_mb:
            # Calculate target bitrate based on file size
            # First, get video duration
            probe_cmd = [
                "ffprobe",
                "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                temp_input
            ]

            probe_result = subprocess.run(probe_cmd, capture_output=True, text=True)
            try:
                duration = float(probe_result.stdout.strip())
            except ValueError:
                duration = 60  # Default fallback

            # Calculate bitrate (in kbps)
            # target_size_mb * 8192 (convert MB to kb) / duration - audio bitrate (128k)
            target_bitrate = int((target_size_mb * 8192) / duration) - 128

            if target_bitrate < 100:
                return {
                    "status": "error",
                    "message": f"Target size {target_size_mb}MB is too small for this video duration"
                }

            cmd = [
                "ffmpeg",
                "-i", temp_input,
                "-b:v", f"{target_bitrate}k",
                "-c:a", "aac",
                "-b:a", "128k",
                "-y",
                temp_output
            ]
            compression_method = f"target size: {target_size_mb}MB"
        else:
            # Use quality preset
            settings = VIDEO_QUALITY_PRESETS[quality]
            cmd = [
                "ffmpeg",
                "-i", temp_input,
                "-c:v", "libx264",
                "-crf", settings["crf"],
                "-preset", settings["preset"],
                "-c:a", "aac",
                "-b:a", "128k",
                "-y",
                temp_output
            ]
            compression_method = f"quality preset: {quality}"

        log.info(f"{log_identifier} Running ffmpeg compression ({compression_method})")

        # Run ffmpeg
        timeout = tool_config.get("timeout_seconds", 900) if tool_config else 900  # 15 min for compression
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if result.returncode != 0:
            log.error(f"{log_identifier} FFmpeg failed: {result.stderr}")
            return {
                "status": "error",
                "message": f"Video compression failed: {result.stderr[:300]}"
            }

        log.info(f"{log_identifier} Compression completed successfully")

        # Read output file
        with open(temp_output, 'rb') as f:
            output_content = f.read()

        # Get original size for comparison
        original_size = os.path.getsize(temp_input)
        compressed_size = len(output_content)
        compression_ratio = (1 - compressed_size / original_size) * 100

        # Generate output filename
        timestamp = datetime.now(timezone.utc)
        input_base = os.path.splitext(input_artifact)[0]
        output_filename = f"{input_base}_compressed{input_ext}"

        # Save as artifact
        metadata_dict = {
            "description": f"Compressed video from {input_artifact}",
            "source_tool": "compress_video",
            "input_artifact": input_artifact,
            "compression_method": compression_method,
            "original_size_bytes": original_size,
            "compressed_size_bytes": compressed_size,
            "compression_ratio_percent": round(compression_ratio, 2),
            "creation_timestamp_iso": timestamp.isoformat(),
        }

        save_result = await save_artifact_with_metadata(
            artifact_service=artifact_service,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=output_filename,
            content_bytes=output_content,
            mime_type=f"video/{input_ext.lstrip('.')}",
            metadata_dict=metadata_dict,
            timestamp=timestamp,
            schema_max_keys=DEFAULT_SCHEMA_MAX_KEYS,
            tool_context=tool_context,
        )

        if save_result.get("status") == "error":
            return {
                "status": "error",
                "message": f"Failed to save artifact: {save_result.get('message')}",
            }

        return {
            "status": "success",
            "message": f"Successfully compressed video ({compression_ratio:.1f}% reduction)",
            "output_artifact": output_filename,
            "output_version": save_result["data_version"],
            "original_size_mb": round(original_size / (1024 * 1024), 2),
            "compressed_size_mb": round(compressed_size / (1024 * 1024), 2),
            "compression_ratio_percent": round(compression_ratio, 2),
        }

    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "message": f"Video compression timed out after {timeout} seconds"
        }
    except FileNotFoundError as e:
        return {
            "status": "error",
            "message": str(e)
        }
    except Exception as e:
        log.exception(f"{log_identifier} Unexpected error: {e}")
        return {
            "status": "error",
            "message": f"Unexpected error during compression: {str(e)}"
        }
    finally:
        try:
            if temp_input and os.path.exists(temp_input):
                os.remove(temp_input)
            if temp_output and os.path.exists(temp_output):
                os.remove(temp_output)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception as e:
            log.warning(f"{log_identifier} Error cleaning up: {e}")
